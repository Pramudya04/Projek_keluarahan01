from django.contrib import admin
from .models import Warga 

admin.site.register(Warga)
